import java.util.ArrayList;
import java.util.Scanner;

class MenuItem {
    private String foodName;
    private double price;

    public MenuItem(String foodName, double price) {
        this.foodName = foodName;
        this.price = price;
    }

    public String getFoodName() {
        return foodName;
    }

    public double getPrice() {
        return price;
    }
}

class Food extends MenuItem {
    public Food(String foodName, double price) {
        super(foodName, price);
    }
}

class CreateBill {
    private ArrayList<MenuItem> items;
    private int count;
    private double sum;

    public CreateBill() {
        items = new ArrayList<>();
        items.add(new Food("Burger", 400.00));
        items.add(new Food("Pizza", 1000.00));
        items.add(new Food("Roti", 100.00));
    }

    public void calculateBill(int count, double price) {
        this.count = count;
        this.sum = count * price;
    }

    public double getSum() {
        return sum;
    }

    public ArrayList<MenuItem> getItems() {
        return items;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("------------------------\n" +
                "|      WELCOME         |\n" +
                "------------------------\n");
        System.out.println("SELECT YOUR CHOICE :");
        System.out.println("1--> BURGER\n" +
                "2--> PIZZA\n" +
                "3--> ROTI");
        System.out.println();

        Scanner scanner = new Scanner(System.in);
        int select = scanner.nextInt();

        if (select == 1 || select == 2 || select == 3) {
            switch (select) {
                case 1:
                    System.out.println("YOUR CHOICE IS BURGER.");
                    break;
                case 2:
                    System.out.println("YOUR CHOICE IS PIZZA.");
                    break;

                case 3:
                    System.out.println("YOUR CHOICE IS ROTI.");
                    break;
            }
        } else {
            System.out.println("ENTER THE VALID FOOD ID - THANK YOU...");
            return;
        }

        System.out.println();
        System.out.println("ENTER THE COUNT :");
        int count = scanner.nextInt();

        CreateBill objBill = new CreateBill();
        objBill.calculateBill(count, objBill.getItems().get(select - 1).getPrice());
        System.out.println("Total Bill: Rs." + objBill.getSum());
    }
}
