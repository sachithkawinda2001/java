class MenuItem {
    String foodName;
    double price;

    public MenuItem(String foodName, double price) {
        this.foodName = foodName;
        this.price = price;
    }
}
